<?php

return [
    'url' => [
        'prefix_admin' => 'huuloc123',
        'prefix_news'  => 'news',   
    ],
];
