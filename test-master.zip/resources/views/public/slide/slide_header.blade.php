     <!-- Header -->
     @include('public.slide.menu_header')
     
    <!-- End Search Popup -->
    <!-- Start Bradcaump area -->
    <div class="ht__bradcaump__area bg-image--3">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="bradcaump__inner text-center">
                        {{--<h2 class="bradcaump-title"><?php
                        $url=$_SERVER['REQUEST_URI'];
                        $url_temp=explode("/",$url);
                             
                            ?></h2>
                        <nav class="bradcaump-content">
                            <a class="breadcrumb_item" href="{{route('home_view')}}">Home</a>
                            <span class="brd-separetor">/</span>
                            <span class="breadcrumb_ite
                            m active">{{ end($url_temp)}}</span>
                        </nav>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Bradcaump area -->
